## world_war_ii_global
This is Ozteas 1941 setup for the Global 40 game.
